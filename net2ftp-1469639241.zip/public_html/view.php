<?php
include_once 'dbconfig.php';
?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">
<a href="index.php" class="btn btn-large btn-info"><i class=""></i>Home </a> 
<a href="add.php" class="btn btn-large btn-info"><i class=""></i>Add Standards </a> 

</div>

<div class="clearfix"></div><br />

<div class="container">
	 <table class='table table-bordered table-responsive'>
     <tr>
     <th>#</th>
     <th>Client</th>
     <th>Name</th>
     <th>Description</th>
     <th>Location</th>
     <th colspan="2" align="center">Actions</th>
     </tr>
     <?php
		$query = "SELECT * FROM std_table";       
		$records_per_page=100;
		$newquery = $crud->paging($query,$records_per_page);
		$crud->dataviewstd($newquery);
	 ?>
    <tr>
        <td colspan="7" align="center">
 			<div class="pagination-wrap">
            <?php $crud->paginglink($query,$records_per_page); ?>
        	</div>
        </td>
    </tr>
 
</table>
   
       
</div>

<?php include_once 'footer.php'; ?>