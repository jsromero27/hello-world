<?php
include_once 'dbconfig.php';
?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">
<a href="add-data.php" class="btn btn-large btn-info"><i class="glyphicon glyphicon-plus"></i> &nbsp; Create New Project </a>
<a href="index2.php" class="btn btn-large btn-info"><i class=""></i>Existing Project </a>
</div>

<div class="clearfix"></div><br />



<?php include_once 'footer.php'; ?>