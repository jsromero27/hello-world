<?php
include_once 'dbconfig.php';
?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">
<a href="index.php" class="btn btn-large btn-info"><i class=""></i>Home </a> 
</div>

<div class="clearfix"></div><br />

<div class="container">
	 <table class='table table-bordered table-responsive'>
     <tr>
     <th>#</th>
     <th>Project Name</th>
     <th>Client</th>
     <th>Project Number</th>
     <th>Project Manager</th>
     <th colspan="3" align="center">Actions</th>
     </tr>
     <?php
		$query = "SELECT * FROM std_table";       
		$records_per_page=20;
		$newquery = $crud->paging($query,$records_per_page);
		$crud->dataviewstdadd($newquery);
	 ?>
    <tr>
        <td colspan="7" align="center">
 			<div class="pagination-wrap">
            <?php $crud->paginglink($query,$records_per_page); ?>
        	</div>
        </td>
    </tr>
 
</table>
   
       
</div>

<?php include_once 'footer.php'; ?>