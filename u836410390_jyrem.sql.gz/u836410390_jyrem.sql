-- MySQL dump 10.15  Distrib 10.0.23-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u836410390_jyrem
-- ------------------------------------------------------
-- Server version	10.0.25-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `std_table`
--

DROP TABLE IF EXISTS `std_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `std_table` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Client` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Division` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Rev_date` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Std_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Desc` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Filename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Location` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `std_table`
--

/*!40000 ALTER TABLE `std_table` DISABLE KEYS */;
INSERT INTO `std_table` VALUES (1,'TxDOT','Bridge','SET','Cross Drainage Max Hw 7\'','03-15','setpcb','set for drainage pipes parallel','setpcb.pdf','http://www.cicis.com/media/1138/pizza_trad_pepperoni.png');
/*!40000 ALTER TABLE `std_table` ENABLE KEYS */;

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proj_num` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `std001` int(10) NOT NULL,
  `std002` int(10) NOT NULL,
  `std003` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_users`
--

/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
INSERT INTO `tbl_users` VALUES (8,'test','test','test','test',0,0,0),(10,'2132','3123213','321321','321321',0,0,0),(11,'323','32321','3213','3123',0,0,0),(13,'323','323','321321','313',0,0,0),(14,'3231','3213','3123','3123',0,0,0),(15,'43','5','5435','553',0,0,0),(16,'777','777','777','777',0,0,0),(17,'555','555','555','555',0,0,0),(18,'555','555','555','555',0,0,0),(19,'555','555','555','555',0,0,0),(20,'434','4343','43434','443343',0,0,0),(21,'434','4343','43434','443343',0,0,0),(22,'434','4343','43434','443343',0,0,0),(23,'434','4343','43434','443343',0,0,0),(24,'434','4343','43434','443343',0,0,0);
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-27 17:06:45
